package br.com.ims.flow.model;

@SuppressWarnings("serial")
public class TransferOutEntity extends AbstractEntity {
	
	
	private String paramName;
	private String paramValue;
	
	public String getParamName() {
		return paramName;
	}
	public void setParamName(String paramName) {
		this.paramName = paramName;
	}
	public String getParamValue() {
		return paramValue;
	}
	public void setParamValue(String paramValue) {
		this.paramValue = paramValue;
	}
	
	
	
	
		
}
