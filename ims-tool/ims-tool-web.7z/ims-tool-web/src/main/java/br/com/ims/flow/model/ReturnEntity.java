package br.com.ims.flow.model;

@SuppressWarnings("serial")
public class ReturnEntity extends AbstractFormEntity{
	
	
	
	
	
		
}
