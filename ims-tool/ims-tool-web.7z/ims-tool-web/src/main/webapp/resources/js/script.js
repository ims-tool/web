function showContent() {  
    $('#textArea').val(PF('graph').getSelectedEvent().content);  
}  